<?php

class profil{
    public $jord;
   public  $dev;

   function __construct($jord,$dev){
       $this->jord=$jord;
       $this->dev=$dev;
   }

   function get_jord(){
       return $this->jord;
   }
   function get_dev(){
       return $this->dev;
       }

}
$profil=new profil("Moffo Yane Jordan","Developpeur web / Mobile");

?>

<div class="entete">
                    <div class="barre">
                        <img src="../image/menu_30px.png" class="">
                        <div class="recherche">
                            <input type="text" placeholder=" Besoin d'un chef de projet ? " class="srch">
                        </div>
                        <div class="search">
                            <img src="../image/search_24px.png" />
                            <img src="../image/vertical_line_24px.png" />
                            <img src="../image/delete_sign_24px.png" />
                        </div>
                    </div>
                    <div class="rond">
                        <div> <img src="../image/IMG_0039.JPG" width="30%" height="150px" class="mon-image" /></div>
                        <div class="texte">
                            <div class="name"><?php echo $profil->get_jord();?></div>
                            <div class="profession"><?php echo $profil->get_dev();?></div>
                        </div>

                    </div>
</div>


