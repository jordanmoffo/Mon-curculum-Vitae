<?php

class en_tete{

    public $expr;
   public $esp;

    function __construct($esp,$expr){
        $this->esp=$esp;
        $this->expr=$expr;
    }

    function get_expr(){
        return   $this->expr;
            }
        
    function get_esp(){
        return $this->esp;
    }

}
$en_tete = new en_tete("Experience Professionnelle","Expertise en entreprise");

?>

                    <div class="en_tete">
                        <div class="en">
                            <div class=""><img src="../image/compagnie.ico" class=""></div>
                            <div>
                                <ol class="campagne">
                                    <li class="exp"><?php echo $en_tete->get_esp() ;?></li>
                                    <li class="ent"><?php echo $en_tete->get_expr() ;?></li>
                                </ol>

                            </div>
                        </div>
                        <div class="trois"><img src="../image/troisp.ico" class="" /></div>
                    </div>