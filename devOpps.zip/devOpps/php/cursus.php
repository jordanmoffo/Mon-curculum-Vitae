<?php 

class cursus{

public $cursuse;
public $dipl_form;
public $electro;
public $emplacement;
public $dated;
public $dom;
public $oracle;
public $emplacement2;
public $date2;
public $dom2;
public $licence;
public $emplacement3;
public $date3;
public $dom3;
public $oracle_certi;
public $emplacement4;
public $date4;
public $dom4;
public $DEC;
public $emplacement6;
public $date6;
public $dom5;
public $bacc;
public $emplacement5;
public $date7;
public $dom6;
public $DEC2;
public $emplacement8;
public $date9;
public $dom9;
public $bacc2;
public $emplacement9;
public $date10;
public $dom10;
public $licence1;
public $emplacement7;
public $date8;
public $dom8;


function  __construct($cursuse,$dipl_form,$electro,$emplacement,$dated,$dom,$oracle,$emplacement2,$date2,$dom2,$licence,$emplacement3,$date3,
 $dom3,$oracle_certi, $emplacement4,$date4,$dom4, $DEC,$emplacement6,$date6,$dom5,$bacc,$emplacement5,$date7,$dom6,$DEC2,$emplacement8,$date9,$dom9,
  $bacc2,$emplacement9,$date10,$dom10, $licence1,$emplacement7,$date8, $dom8){
	  $this->cursuse=$cursuse;
	  $this->dipl_form=$dipl_form;
	  $this->electro=$electro;
	  $this->emplacement=$emplacement;
	  $this->dated=$dated;
	  $this->dom=$dom;
	  $this->oracle=$oracle;
	  $this->emplacement2=$emplacement2;
	  $this->date2=$date2;
	  $this->dom2=$dom2;
	  $this->licence=$licence;
	  $this->emplacement3=$emplacement3;
	  $this->date3=$date3;
	  $this->dom3=$dom3;
	  $this->oracle_certi=$oracle_certi;
	  $this->emplacement4=$emplacement4;
	  $this->date4=$date4;
	  $this->dom4=$dom4;
	  $this->DEC=$DEC;
	  $this->emplacement6=$emplacement6;
	  $this->date6=$date6;
	  $this->dom5=$dom5;
	  $this->bacc=$bacc;
	  $this->emplacement5=$emplacement5;
	  $this->date7=$date7;
	  $this->dom6=$dom6;
	  $this->DEC2=$DEC2;
	  $this->emplacement8=$emplacement8;
	  $this->date9=$date9;
	  $this->dom9=$dom9;
	  $this->bacc2=$bacc2;
	  $this->emplacement9=$emplacement9;
	  $this->date10=$date10;
	  $this->dom10=$dom10;
	  $this->licence1=$licence1;
	  $this->emplacement7=$emplacement7;
	  $this->date8=$date8;
	  $this->dom8=$dom8;
}

function get_cursuse(){
	 return $this->cursuse;
}
function get_dipl_form(){
 return $this->dipl_form;
}
function get_electro(){
	return $this->electro;
}
function get_emplacement(){
	return  $this->emplacement;
}
function get_dated(){
	return $this->dated;
}
function get_dom(){
	return $this->dom;
}
function get_oracle(){
	return $this->oracle;
}
function get_emplacement2(){
	return $this->emplacement2;
}
function get_date2(){
	return $this->date2;
}
function get_dom2(){
return	 $this->dom2;
}
function get_licence(){
	return $this->licence;
}
function get_emplacement3(){
	return $this->emplacement3;
}
function get_date3(){
	return $this->date3;
}
function get_dom3(){
	return $this->dom3;
}
function get_oracle_certi(){
	return $this->oracle_certi;
}
function get_emplacement4(){
	return $this->emplacement4;
}
function get_date4(){
	return $this->date4;
}
function get_dom4(){
	return $this->dom4;
}
function get_DEC(){
	return $this->DEC;
}
function get_emplacement6(){
return	 $this->emplacement6;
}
function get_date6(){
	return $this->date6;
}
function get_dom5(){
	return $this->dom5;
}
function get_bacc(){
	return $this->bacc;
}
function get_emplacement5(){
	return $this->emplacement5;
}
function get_date7(){
	return $this->date7;
}
function get_dom6(){
	return $this->dom6;
}
function get_DEC2(){
return	 $this->DEC2;
}
function get_emplacement8(){
	return $this->emplacement8;
}
function get_date9(){
return	 $this->date9;
}
function get_dom9(){
	return $this->dom9;
}
function get_bacc2(){
	return $this->bacc2;
}
function get_emplacement9(){
return	 $this->emplacement9;
}
function get_date10(){
	return $this->date10;
}
function get_dom10(){
	return $this->dom10;
}
function get_licence1(){
	return $this->licence1;
}
function get_emplacement7(){
	return $this->emplacement7;
}
function get_date8(){
	return $this->date8;
}
function get_dom8(){
	return $this->dom8;
}
}

$cursus=new cursus("Cursus Academique","Diplomes et formations Certifiantes","DIPET 2 Electrotechnique","- @ENSET de Douala","aout 2016 -",
" gestion d'eclairage d'une maison (Android +Arduino)","Oracle Certified Associate","- @Kentnix Sarl","Mars 2009 -","Oracle Database 11g Administration",
"Licence professionnele","- @Douala INStitute of Tech","Octobre 2008-","Telecommunication & reseauxL","Oracle SQL Certified","- @Kentnix Sarl",
"Decembre 2008 -","SQL2,SQL3, XML","DEC / BTS","- @CCMB Dieppe","Septembre 2007-","Programmation Appliquée Pour Internet","Baccalaureat",
"- @Lycee Technique de Douala Bassa","Juin 2005-","Electrotechnique,mention BIEN (major de centre)","DEC / BTS","- @CCMB Dieppe","Septembre 2007-",
"Programmation Appliquée Pour Internet","Baccalaureat","- @Lycee Technique de Douala Bassa","Juin 2005-","Electrotechnique,mention BIEN (major de centre)",
"Licence professionnele","- @Douala INStitute of Tech","Octobre 2008-","Telecommunication & reseauxL");
?>




<div class="cursus">

<div class="en_tete">
    <div class="en">
        <div class="call"><img src="../image/compagnie.ico" class="call"></div>
        <div>
            <ol class="campagne">
                <li class="exp"><?php echo $cursus->get_cursuse(); ?></li>
                <li class="ent"><?php echo $cursus->get_dipl_form(); ?></li>
            </ol>

        </div>
    </div>
    <div class="trois"><img src="../image/troisp.ico" class="" /></div>
</div>

<div class="bad">
    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_electro(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_dated(); ?><i class="color"> <?php echo $cursus->get_dom(); ?></i> </li>
               
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>

    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_oracle(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement2(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date2(); ?><i class="color">  <?php echo $cursus->get_dom2(); ?></i> </li>
               
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>

    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a> <?php echo $cursus->get_oracle_certi(); ?></a></div>
            <div class="light41"><strong> <?php echo $cursus->get_emplacement4(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date4(); ?><i class="color"> <?php echo $cursus->get_dom4(); ?></i> </li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>


    <div class="bascentral">


        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_licence(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement3(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date3(); ?><i class="color">  <?php echo $cursus->get_dom3(); ?></i> </li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>


    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a> <?php echo $cursus->get_DEC(); ?></a></div>
            <div class="light41"><strong> <?php echo $cursus->get_emplacement6(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"> <?php echo $cursus->get_date6(); ?><i class="color"> <?php echo $cursus->get_dom5(); ?></i> </li>
            </ol>
        </div>
        <hr class="light2">
    </div>

    <div class="bascentral">


        <div class="ba1">
            <div class="light3"><a> <?php echo $cursus->get_bacc(); ?></a></div>
            <div class="light41"><strong> <?php echo $cursus->get_emplacement5(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"> <?php echo $cursus->get_date7(); ?><i class="color"> <?php echo $cursus->get_dom6(); ?></i> </li>
            </ol>
        </div>
        <hr class="light2">
    </div>


    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_DEC2(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement8(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date9(); ?><i class="color"><?php echo $cursus->get_dom9(); ?></i> </li>
            </ol>
        </div>
        <hr class="light2">
    </div>

    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_bacc2(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement9(); ?></strong></div>
           
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date10(); ?><i class="color"><?php echo $cursus->get_dom10(); ?></i> </li>
            </ol>
        </div>
        <hr class="light2">
    </div>

    
    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a><?php echo $cursus->get_licence1(); ?></a></div>
            <div class="light41"><strong><?php echo $cursus->get_emplacement7(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $cursus->get_date8(); ?><i class="color"><?php echo $cursus->get_dom8(); ?></i> </li>
            </ol>
        </div>
        <div>
            
        </div>
    </div>

</div>

</div>