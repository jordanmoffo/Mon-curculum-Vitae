<?php 

class double{
public $anne;
public $natio;
public $situa;
public $residence;
public $ville;
public $map;
public $tel;
public $nbre_aboné;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
public $email;
public $site;
public $projet;
public $contrat;
public $expd;

function __construct($anne,$natio,$situa,$residence,$ville,$map,$tel,$nbre_abonné,$email,$site,$projet,$contrat,$expd)
{
    $this->anne=$anne;
    $this->natio=$natio;
    $this->situa=$situa;
    $this->residence=$residence;
    $this->ville=$ville;
    $this->map=$map;
    $this->tel=$tel;
    $this->nbre_aboné=$nbre_abonné;
    $this->email=$email;
    $this->site=$site;
    $this->projet=$projet;
    $this->contrat=$contrat;
    $this->expd=$expd;
}
function get_anne(){
    
   return $this->anne;
}
function get_natio(){
   return $this->natio;
}
function get_situa(){
    return $this->situa;
}
function get_residence(){
  return  $this->residence;
}
function get_ville(){
  return  $this->ville;
}
function get_map(){
  return  $this->map;
}
function get_tel(){
  return  $this->tel;
}
function get_nbre_aboné(){
  return  $this->nbre_aboné;
}
function get_email(){
 return $this->email;
}
function get_site(){
   return $this->site;
}
function get_projet(){
  return   $this->projet;
}
function get_contrat(){
  return  $this->contrat;
}
function get_expd(){
   return $this->expd;
}
}
$double=new double("Nee le 20 Octobre 1986","Originaire du sud Cameroun","Marie,02 enfant- Sante RAS","Residant a Ndogbong","Douala - Cameroun",
"Map: 4.053276, 9.765047","(237) 674 053 983","Mobile, Telegram, Whatsapp","junioressono@gmail.com","Google+,TWitter,Linkedin,Github",
"+45 PROJETS","+31 CONTRATS","12 ANS D'EXP");
?>

<div class="profil">

    <div class="ronde">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

        <div class='button-parent'>
            <input type="checkbox" id='btn'>
            <label for="btn" class='button'>
                <i class="material-icons" width="30%" height="150px">+</i>
            </label>

            <div class="link-parent">
                <a href='#' class='link-item' id='link-one'>
                    <i class="material-icons">+</i>
                </a>
                <a href='#' class='link-item' id='link-two'>
                    <i class="material-icons">+</i>
                </a>
            </div>
        </div>
    </div>
    <div class="globe">
        <div>
            <ol class="inf1">
                <div class="ico"> <img src="../image/anive.ico" class="icone" /></div>
                <div class="mail">
                    <ul><?php echo $double->get_anne()?></ul>
                    <ul> <?php echo $double->get_natio()?></ul>
                    <ul> <?php echo $double->get_situa()?></ul>
                </div>
            </ol>
            <hr class="light_hr1">
        </div>


        <div>
            <ol class="inf1">

                <div class="ico"><img src="../image/map.ico" class="icone"></div>
                <div class="mail">
                    <ul> <?php echo $double->get_residence()?></ul>
                    <ul> <?php echo $double->get_ville()?> </ul>
                    <ul> <?php echo $double->get_map()?></ul>
                </div>
            </ol>
            <hr class="light_hr1">
        </div>


        <div>
            <ol class="inf1">
                <div class="ico"><img src="../image/call.ico" class="icone"></div>
                <div class="mail">
                    <ul><?php echo $double->get_tel()?></ul>
                    <ul> <?php echo $double->get_site()?></ul>
            </ol>
            <hr class="light_hr1">
        </div>

        <div>
            <ol class="inf1">
                <div class="ico"><img src="../image/mail.ico" class="icone"> </div>
                <div class="mail">
                    <ul> <?php echo $double->get_email()?></ul>
                    <ul> <?php echo $double->get_nbre_aboné()?></ul><br>
            </ol>
        </div>
        <div class="fin">
            <div><?php echo $double->get_projet()?></div>
            <div><?php echo $double->get_contrat()?></div>
            <div><?php echo $double->get_expd()?></div>
        </div>
    </div>
</div>