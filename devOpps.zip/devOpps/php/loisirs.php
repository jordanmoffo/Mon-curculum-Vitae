<?php

class loisirs{


public $point;
public $citation;
public $lang;
public  $prt_entreprise;  
public  $frcs;
public $angl;

function __construct($point,$citation,$lang,$prt_entreprise,$frcs,$angl)
{
    $this->point=$point;
    $this->citation=$citation;
	$this->lang=$lang;
    $this->prt_entreprise=$prt_entreprise;
    $this->frcs=$frcs;
    $this->angl=$angl;
    
}

function get_point(){
    return $this->point;
}
function get_citation(){
    return $this->citation;
}
function get_lang(){
    return $this->lang;
}

function get_prt_entreprise(){
    return $this->prt_entreprise;
}
function get_frcs(){
    return $this->frcs;
}
function get_angl(){
    return $this->angl;
}
}
$loisirs=new loisirs("Point d'interet","simple passe-temps pour se faire un peu plaisir","Langue","Pratiquées en entreprise","Francais","Anglais");
?>


        <div class="loisirs">
                    <div class="point_interet">

                        <div class="pra">
                            <ol>
                                <li class="ineteret"><strong><?php echo $loisirs->get_point(); ?></strong> </li>
                                <li class="ptt"><i><?php echo $loisirs->get_citation(); ?></i></li>
                            </ol>


                            <div class="png">
                                <img src="../image/image2.png" alt="image" class="jpg" width="100%">
                            </div>
                        </div>
                    </div>
                    <div class="langue">
                        <div class="pra">
                            <ol>
                              <li class="ineteret"><strong><?php echo $loisirs->get_lang()?></strong> </li>
                                <li class="ptt"><i><?php echo $loisirs->get_prt_entreprise(); ?></i></li>
                            </ol>


                            <div class="lang">
                                <ol class="oll">
                                    <li>
                                        <div><input type="checkbox" checked class="rev"><?php echo $loisirs->get_frcs();; ?></div>
                                    </li>
                                    <li>
                                        <div><input type="checkbox" checked class="rev"><?php echo $loisirs->get_angl(); ?></div>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                
            </div>
