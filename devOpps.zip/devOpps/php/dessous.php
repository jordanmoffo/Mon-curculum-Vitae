<?php

class dessous{

public $tec;
public $ets1;
public $date1;
public $dom1;
public $fond;
public $dom2;
public $date2;
public $dom3;
public $enseig;
public $ecole;
public $date3;
public $dom4;
public $dev_chef;
public $dom5;
public $date4;
public $special;
public $resp;
public $dom6;
public $date5;
public $special2;

public function __construct($tec,$ets1,$date1,$dom1,$fond,$dom2,$date2,$dom3,$enseig,$ecole,$date3,$dom4,
$dev_chef,$dom5,$date4,$special,$resp,$dom6,$date5,$special2)
{
    $this->tec=$tec;
    $this->ets1=$ets1;
    $this->date1=$date1;
    $this->dom1=$dom1;
    $this->fond=$fond;
    $this->dom2=$dom2;
    $this->date2=$date2;
    $this->dom3=$dom3;
    $this->enseig=$enseig;
    $this->ecole=$ecole;
    $this->date3=$date3;
    $this->dom4=$dom4;
    $this->dev_chef=$dev_chef;
    $this->$dom5=$dom5;
    $this->date4=$date4; 
    $this->special=$special;
    $this->resp=$resp;
    $this->dom6=$dom6;   
    $this->date5=$date5;
    $this->special2=$special2;  
}


 function get_tec(){
    return $this->tec;
 }
 function get_ets1(){
     return $this->ets1;
 }
 function get_date1(){
    return $this->date1;
}
function get_dom1(){
    return $this->dom1;
}
function get_fond(){
    return $this->fond;
}
function get_dom2(){
    return $this->dom2;
}
function get_date2(){
    return $this->date2;
}
function get_dom3(){
    return $this->dom3;
}
function get_enseig(){
    return $this->enseig;
}
function get_ecole(){
    return $this->ecole;
}
function get_date3(){
    return $this->date3;
}
function get_dom4(){
    return $this->dom4;
}
function get_dev_chef(){
    return $this->dev_chef;
}
function get_dom5(){
    return $this->dom5;
}
function get_date4(){
    return $this->date4;
}
function get_special(){
    return $this->special;
}
function get_resp(){
    return $this->resp;
}
function get_dom6(){
    return $this->dom6;
}
function get_date5(){
    return $this->date5;
}
function get_special2(){
    return $this->special2;
}
}
$dessous=new dessous("Chef des projets technologiques","- @Ets.M DE M","juillet 20219 a ce jour - http://mdem.cm","chef du projet annulaire - unversel.cm de l'ART",
"Fondateur & DT","- @Startup chickDev","De juin 2915 a ce jour - http://chickdev.com","Realisation de plusieur sites web et application","Enseignant",
"- @Institut Universitaire de la Cote","Octobre 2011 a ce jour - http://istdi.net","Analyse UML & MERISE, BD/SQL. ORACLE & MySQL,Dev IOS & ANDROID
BI & Big Data & Hadoop 1,2 et 4 annee","Developpeur en chef","- @Kayroal group","De Mai 2013 a juin 2015 - http://khayroual.com","Realisation de multiples projets logiciel et web, infographie,...",
"Responsable commercial","- @BAO Sarl","De Decembre 2012 a juin 2013 - http://bao-sarl.com","Definition des strategies commerciales, Controle de qualite, suivi..");
?>


<div class="bas">
    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a><?php echo $dessous->get_tec(); ?></a></div>
            <div class="light41"><strong><?php echo $dessous->get_ets1(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $dessous->get_date1(); ?></li>
                <li class="date"><?php echo $dessous->get_dom1(); ?></li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>

    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a><?php echo $dessous->get_fond(); ?></a></div>
            <div class="light41"><strong><?php echo $dessous->get_dom2(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $dessous->get_date2(); ?></li>
                <li class="date"><?php echo $dessous->get_dom3(); ?></li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>

    <div class="bascentral">
        <div class="ba1">
            <div class="light3"><a><?php echo $dessous->get_enseig(); ?></a></div>
            <div class="light41"><strong><?php echo $dessous->get_ecole(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $dessous->get_date3(); ?></li>
                <li class="date"><?php echo $dessous->get_dom4(); ?></li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>


    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a><?php echo $dessous->get_dev_chef(); ?></a></div>
            <div class="light41"><strong><?php echo $dessous->get_dom5(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $dessous->get_date4(); ?></li>
                <li class="date"><?php echo $dessous->get_special(); ?></li>
            </ol>
        </div>
        <div>
            <hr class="light2">
        </div>
    </div>

    <div class="bascentral">

        <div class="ba1">
            <div class="light3"><a><?php echo $dessous->get_resp(); ?></a></div>
            <div class="light41"><strong><?php echo $dessous->get_dom6(); ?></strong></div>
        </div>


        <div class="an">
            <ol>
                <li class="dated"><?php echo $dessous->get_date5(); ?></li>
                <li class="date"><?php echo $dessous->get_special2(); ?></li>
            </ol>
        </div>
    </div>



</div>